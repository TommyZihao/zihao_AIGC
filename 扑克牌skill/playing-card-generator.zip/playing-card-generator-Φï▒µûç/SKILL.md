---
name: "playing-card-generator"
description: "生成可打印的手绘水彩风格扑克牌图像。用户指定牌号、花色和图案内容即可生成。当用户想制作扑克牌、poker card 或整副牌组时调用此技能。"
---

# 扑克牌生成器

生成手绘水彩风格的可打印扑克牌图像。每张牌以定制插画作为主图案，搭配标准扑克牌版式元素。

## 何时调用

- 用户想生成扑克牌 / poker card
- 用户想创建一整副定制扑克牌
- 用户指定了牌号（A, 2-10, J, Q, K）和/或花色（黑桃/红桃/梅花/方块）及图案内容
- 用户想生成牌背图案（card back）
- 用户提到扑克牌、playing card、poker card

## 输入参数

用户提供：
1. **牌号**（rank）：A, 2, 3, 4, 5, 6, 7, 8, 9, 10, J, Q, K, 小王, 大王
2. **花色**（suit）：黑桃(spade) / 红桃(heart) / 梅花(club) / 方块(diamond)——大小王无花色
3. **图案内容**（subject）：对要绘制内容的描述（如地标、动物、植物、人物等）
4. **图案名称**（subject_name）：显示在牌上的简短文字标签（通常 2-6 个中文字）

## 视觉风格规范

所有牌必须统一遵循以下风格规则：

1. **构图**：竖向（纵向）构图——主体须表现为高耸、纵向的场景，强调高度与纵深感，而非宽阔的横向铺展
2. **艺术风格**：手绘水彩，搭配精致墨线。柔和的水彩晕染结合细腻的笔触线条
3. **配色**：忠于主体真实外观的自然均衡色彩。不要默认使用暖土色调、赭石色、赤陶色或砂岩色——让每个主体拥有自己的自然色彩
4. **边框**：牌边仅一条极细的黑色线条。无装饰花纹、无繁复元素、无花哨边框——只需一条干净简洁的线
5. **背景**：米白色，带轻微做旧纸张纹理
6. **牌面元素布局**（严格遵循以下规范）：
   - **左上角**：牌号字母/数字在上方，**正下方**放**一个**花色符号（上下垂直排列，非左右并排）。使用优雅的书法字体。**每个角落只有一个花色符号**——不要出现一大一小两个符号
   - **右下角**：与左上角完全相同的牌号 + 花色符号，但**整体旋转 180 度**（倒置），如同真实扑克牌。即牌号在上、花色在下的布局旋转后变为花色在上、牌号在下
   - **右上区域**：图案名称的小号中文文字，颜色为低调的深棕色，小而不突兀。**确保中文字符正确，无多余或重复的字**
   - 花色颜色：黑桃♠和梅花♣为**黑色**，红桃♥和方块♦为**红色**
7. **整体美感**：中国画风格与西式扑克牌设计的融合。高品质、细节丰富、具艺术感、收藏版质感

## 提示词模板

将此模板用于 GenerateImage 工具。将 `{rank}`、`{suit}`、`{suit_symbol}`、`{subject_name}`、`{subject_description}` 替换为实际值：

```
[Playing card design]: A beautifully crafted playing card featuring {subject_description}. Hand-drawn watercolor illustration style with a natural balanced color palette. VERTICAL composition — the scene emphasizes vertical height and depth. The center shows {subject_description}. Delicate ink line work combined with soft watercolor washes in natural true-to-life colors. The card has a clean playing card layout: the central illustration fills the card, bordered only by a single thin minimal black line around the edge — no decorative patterns, no ornate elements, just one simple clean line. Inside the illustration area, in the upper right corner, there is a small Chinese text "{subject_name}" written in subtle dark brown color, small and unobtrusive. In the top-left corner: large "{rank}" in elegant calligraphic font, with a SINGLE {suit_color} {suit} suit symbol placed DIRECTLY BELOW the rank (vertically stacked, not side by side). Only ONE suit symbol per corner — do NOT add a second symbol. In the bottom-right corner: the exact same "{rank}" and the exact same SINGLE {suit_color} {suit} suit symbol, both rotated 180 degrees upside down as in real playing cards. Both corners must show the exact same suit symbol. Off-white background with subtle aged paper texture. Fusion of Chinese painting style with Western playing card design. High quality, detailed, artistic, collector's edition.
```

### 参数参考

| 参数 | 取值 | 示例 |
|-----------|--------|---------|
| `{rank}` | A, 2, 3, 4, 5, 6, 7, 8, 9, 10, J, Q, K, 小王, 大王 | "K" |
| `{suit}` | spade, heart, club, diamond | "spade" |
| `{suit_color}` | BLACK（黑桃/梅花）, RED（红桃/方块） | "BLACK" |
| `{subject_name}` | 简短中文名称（2-6 字） | "云冈石窟" |
| `{subject_description}` | 对图案内容的详细英文描述 | "the Yungang Grottoes in Shanxi, China, featuring massive Buddha statues carved into cliff faces, rows of Buddhist caves, and intricate stone carvings" |

### 大小王（Joker）

对于大小王（小王/大王），修改模板：
- 移除花色相关内容
- 牌号使用 "小王" 或 "大王"
- 无需花色符号
- 可使用特殊装饰元素代替花色

### 牌背（Card Back）

牌背是整副牌共用的统一背面图案，不含牌号和花色。用户生成整副牌时，应同时生成一张牌背。

#### 输入参数

1. **主题内容**（back_subject）：牌背中心图案的描述（如某个地标、文化符号等）
2. **主题名称**（back_name）：牌背主题的简短中文标签（可选）

#### 牌背视觉风格规范

1. **构图**：竖向构图，与牌面一致
2. **艺术风格**：手绘水彩，搭配精致墨线，与牌面风格统一
3. **对称性**：设计应左右对称，适合作为统一的牌背图案
4. **中心图案**：以一个标志性主题为中心，搭配传统装饰纹样（如云纹、山峦剪影、几何花纹等）
5. **装饰边框**：可使用比牌面稍丰富的装饰边框（传统中式几何纹样、花卉纹等），但仍保持简洁优雅
6. **配色**：与整副牌风格协调，可使用金色、深红、淡蓝等装饰色调
7. **边框**：牌边一条细黑色线条
8. **背景**：米白色做旧纸张纹理
9. **无文字**：牌背不应出现牌号、花色或名称文字（纯装饰图案）

#### 牌背提示词模板

```
[Playing card back design]: A beautifully crafted playing card BACK design featuring {back_subject_description}. Hand-drawn watercolor illustration style with delicate ink line work. VERTICAL composition, symmetric and decorative, suitable as a uniform card back. The central motif is {back_subject_description}, surrounded by subtle traditional Chinese cloud patterns and mountain silhouettes. Ornamental border with traditional Chinese geometric patterns and floral motifs in muted gold, deep red, and soft blue watercolor tones. The entire card is framed by a single thin black line border. Off-white aged paper texture background with subtle watercolor wash. Fusion of Chinese painting aesthetic with Western playing card design. High quality, detailed, artistic, collector's edition. No text, no numbers, no rank, no suit symbols — purely decorative pattern.
```

#### 牌背命名规则

保存牌背时，文件命名为：`牌背.jpg`（或用户指定名称）

## GenerateImage 设置

- **image_size**：`portrait_4_3`（标准扑克牌比例，接近 2.5:3.5 英寸的扑克牌尺寸）
- **path**：保存到用户指定目录，默认为 `{workspace}/playing_cards/`

## 批量生成

生成整副牌（54 张 + 牌背）时：
1. 与用户确认完整牌组列表（52 张标准牌 + 2 张大小王）
2. 确认所有图案内容及其对应的牌位分配
3. 确认牌背主题内容
4. 逐张生成（每次只调用一次 GenerateImage——不要并行调用）
5. 按以下命名规则保存每张牌：`{rank}_{suit}_{subject_name}.jpg`
   - 示例：`K_spade_云冈石窟.jpg`
   - 大小王：`小王_joker_{subject_name}.jpg`
   - 牌背：`牌背.jpg`

## 质量检查清单

确认某张牌完成前，检查：
- [ ] 竖向构图（非横向/宽幅）
- [ ] 自然色彩（非统一的黄色/暖色）
- [ ] 单根细线边框（无繁复装饰）
- [ ] **左上角：牌号在上方，一个花色符号在正下方**（上下垂直排列）
- [ ] **右下角：与左上角相同的牌号+花色，整体旋转 180 度**（倒置）
- [ ] **每个角落只有一个花色符号**——不能出现一大一小两个
- [ ] **花色颜色正确**：黑桃♠/梅花♣为黑色，红桃♥/方块♦为红色
- [ ] **图案名称中文字符正确**，无多余或重复的字
- [ ] 图案名称为小号文字，位于右上区域
- [ ] 米白色做旧纸张背景
- [ ] 手绘水彩风格，带墨线

### 牌背质量检查

- [ ] 竖向构图，与牌面一致
- [ ] 左右对称的装饰性设计
- [ ] 无牌号、无花色、无文字（纯装饰图案）
- [ ] 装饰边框简洁优雅，不过于繁复
- [ ] 配色与整副牌风格协调
- [ ] 手绘水彩风格，与牌面统一

## 常见问题与规避

以下问题在生成中容易反复出现，必须在提示词中明确规避：

1. **花色符号重复**：AI 容易在每个角落生成一大一小两个花色符号。必须在提示词中强调 "Only ONE suit symbol per corner — do NOT add a second symbol"
2. **花色位置错误**：花色符号容易出现在数字旁边而非下方。必须强调 "placed DIRECTLY BELOW the rank (vertically stacked, not side by side)"
3. **右下角未旋转**：右下角的牌号和花色经常未被旋转 180 度。必须强调 "both rotated 180 degrees upside down as in real playing cards"
4. **花色颜色错误**：方块♦和红桃♥有时被生成为黑色。必须明确指定 "RED" 或 "BLACK"
5. **花色形状混淆**：梅花♣有时被画成黑桃♠形状。可补充描述 "club symbol looks like a three-leaf clover with three round petals"
6. **中文字符重复**：图案名称有时会多出重复的字（如"常家庄庄园"而非"常家庄园"）。生成后需检查文字正确性

## 重要说明

- GenerateImage 调用必须逐张进行（一次一张），不可并行
- 每张牌的生成需要时间——请向用户报告进度
- 若某张牌未达到质量标准，调整描述后重新生成
- 提示词使用英文以获得最佳图片生成效果，但图案名称保持中文
- 描述图案内容时，应自然地强调竖向构图（高楼、深谷、参天大树、仰视视角等）
