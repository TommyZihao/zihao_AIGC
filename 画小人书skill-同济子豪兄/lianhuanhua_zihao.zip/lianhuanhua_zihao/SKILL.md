---
name: "lianhuanhua_zihao"
description: "Creates 1980s-style Chinese lianhuanhua (连环画) picture books from story text. Invoke when user wants to turn a novel/story/script into a traditional Chinese comic book with ink illustrations and embedded Chinese text, or mentions 连环画/小人书/lianhuanhua."
updated: "2026-07-26 09:19"
---

# 连环画创作器 (Lianhuanhua Creator)

> **修改时间：2026-07-26 09:19** — 调整文字/插画比例（文字28%→18%，插画72%→82%），新增配文精简要求


将小说、故事、剧本等文字内容，创作成80年代风格的中国传统连环画（小人书）。每本连环画包含**封面 + 8页内页 + 封底**，每页为7:5横屏图片，文字以像素形式原生呈现在画面上方约18%区域，下方约82%为工笔白描插画（插画占主体）。**每本同步输出黑白版和彩色版两个版本。** 最终交付**图片 + PDF**（不交付HTML）。

## 适用场景

- 用户想把一段故事/小说/剧本画成连环画
- 用户提到"连环画"、"小人书"、"lianhuanhua"
- 用户想把文字内容变成图文一体的传统风格漫画书

## 完整工作流程

### 第一步：确认画风

无需用户上传参考图，直接采用默认的80年代中国传统连环画画风。skill 内置了一张杨家将小人书参考图（`assets/杨家将参考图.jpeg`），可用 Read 工具查看其画风特征：

- 线描技法（铁线描、兰叶描、斧劈皴、交叉排线）
- 构图风格（中国传统绘画+苏联现实主义融合）
- 明暗处理（高对比黑白、平涂黑块）
- 人物造型（英雄现实主义、剑眉星目）
- 印刷质感（单色印刷、老化纸张）

如用户另行上传参考图，可用 Read 工具分析并据此调整上述特征。

### 第二步：拆分分镜

将用户提供的文字内容按叙事节奏拆分为多个分镜场景（通常6-10页）：
- 每页一个独立场景，对应一段配文
- 配文从原文中提取，保持文学性
- 为每页拟定中文数字回目标题（一、二、三...或壹、贰、叁...）

### 第三步：逐页生成图片（封面 + 内页 + 封底）

使用 GenerateImage 工具逐页生成。**关键参数和prompt要求：**

**图片尺寸：** `2800x2000`（7:5横屏比例）

**每本共生成10张图片：封面(cover) + 8页内页(page01~page08) + 封底(back)**

**页面排列顺序（双面打印）：**

由于小人书是双面打印，封面为第1张（奇数页，印在纸张正面），内页依次排列。**封底必须是第偶数张图**，确保打印后封底落在书底（纸张背面的最后一页）。

标准10页排列：`cover(1) → page01(2) → page02(3) → page03(4) → page04(5) → page05(6) → page06(7) → page07(8) → page08(9) → back(10)`

- 封面 = 第1张（奇数）
- 封底 = 第10张（偶数）✓

若内页数为奇数张，需在封底前插入一张空白页或增加一页内页，**确保封底始终排在偶数位**。

#### A. 封面生成（cover）

封面是一张**全彩全画幅、无边框、出血式设计**的7:5图片。参考1970-80年代经典连环画封面（如《鸡毛信》《闪闪的红星》《地雷战》）的视觉风格：画面占满整个画幅，无任何边框，仅以醒目的书法风格标题作为文字元素。

**封面统一为彩色**，无论黑白版还是彩色版，封面图均为彩色（黑白版的封面也是彩色的）。

prompt必须包含：

```
A WIDE HORIZONTAL FULL-COLOR COVER illustration from a 1970s-80s Chinese 连环画 (lianhuanhua).
Ratio is 7:5. BLEED-TO-EDGE design: NO borders, NO frame, NO margins. The illustration fills the ENTIRE canvas edge to edge.

FULL-COLOR PAINTING STYLE: 1970s Chinese propaganda poster / traditional gouache painting style. Rich saturated colors - revolutionary reds, warm ochre yellows, deep blues, earthy greens. Hand-painted gouache / watercolor texture with visible brushstrokes. Vintage offset printing texture with slight grain. Heroic realism aesthetic.

ILLUSTRATION: [本章节关键场景的描述]. Heroic central figure composition, dynamic action pose. The illustration should fill 85-90% of the canvas as a full painting.

TITLE OVERLAY: Bold Chinese calligraphy-style title characters "本本标题" rendered as large brush-calligraphy (书法体/行草书), in striking red or gold color, positioned prominently on the illustration. The title should be the ONLY text on the cover. NO other text, NO subtitles, NO author names, NO chapter numbers, NO seal stamps. Just the calligraphy title overlaid on the full-color illustration.

CRITICAL: NO border, NO frame, NO decorative border patterns. NO text other than the title. The cover is a single full-bleed color painting with only the calligraphy title.
```

**封面关键要求：**
1. **全彩**：封面统一为彩色水粉/宣传画风格，无论黑白版还是彩色版
2. **无边框**：出血式设计，画面延伸至画布边缘，无任何边框或装饰边
3. **书法标题**：仅保留醒目的书法风格标题（行草书/美术字），红色或金色
4. **不加其余文字**：不放副标题、作者名、章节号、印章等其他文字
5. **参考画风**：1970年代中国连环画封面（如《鸡毛信》《地雷战》），手绘水粉质感，英雄现实主义

#### B. 内页生成（page01 ~ page08）

**每页prompt必须包含以下要素：**

1. **格式声明：**
   ```
   A WIDE HORIZONTAL landscape-format page from a 1980s Chinese 连环画 (lianhuanhua). 
   The image MUST fill the entire wide horizontal canvas edge to edge. 
   Ratio is 7:5 (much wider than tall).
   CRITICAL: The composition must spread horizontally across the FULL width. 
   Do NOT leave empty margins on left/right sides. Fill the entire image area.
   ```

2. **文字区域（上方约18%）：**
   ```
   TOP SECTION (upper 18%, full width): A COMPACT horizontal text band spanning ENTIRE width.
   White background, Chinese characters in Song typeface (宋体), black ink, thin border.
   - Title left: "X  回目标题"
   - Page number right: "X"
   - Body text: "配文内容..." (keep to 2-3 lines max, concise)
   CRITICAL: The text band must be COMPACT, occupying only the upper 18% of the page.
   Keep body text SHORT - extract only the key 1-2 sentences from the source material.
   Do NOT include long paragraphs. Fewer lines = bigger illustration.
   ```

3. **插画区域（下方约82%）：**
   ```
   BOTTOM SECTION (lower 82%, full width): WIDE PANORAMIC black-and-white pen-and-ink 
   illustration. [场景描述]. Wide horizontal composition filling frame edge to edge.
   The illustration is the MAIN content and must occupy the large majority (82%) of the page.
   ```

4. **风格声明（黑白版）：**
   ```
   STYLE: Pure black and white, strictly grayscale, NO color, NO sepia. 
   Traditional 工笔白描 line drawing. Aged 1980s printed comic book look with 
   slight ink wear. Thin black border around entire page.
   ```

4. **风格声明（彩色版）：**
   ```
   COLOR PALETTE: Muted retro 1980s Chinese color lithography style. Warm earth tones 
   - ochre yellows, burnt sienna reds, grey-blues, muted browns and olives. Vintage 
   offset-printed comic book colors with slight color misregistration.
   STYLE: Traditional 工笔白描 line drawing with soft watercolor fill. Aged 1980s 
   printed look. Thin decorative border around entire page.
   ```

#### C. 封底生成（back）

封底是一张7:5图片，简洁优雅，**包含清晰的正常文字**（版权信息、作者署名等）。**封底不做模糊做旧处理**，文字必须清晰可读。

prompt：

```
A WIDE HORIZONTAL landscape-format BACK COVER page from a 1980s Chinese 连环画.
Ratio is 7:5. Fill the entire image area.

CENTER: A decorative colophon/oriental ornament pattern (◆ ◇ ◆ or traditional seal)
Below: "原著：刘慈欣《三体》"
"连环画编绘：同济子豪兄 · Trae Work · Seedream"
"画风参考：1980年代中国传统连环画技法"
A small price tag box in corner like "定价：0.00元" for vintage authenticity

CRITICAL: All text must be SHARP, CLEAR and READABLE. Do NOT apply any blur, noise, aging or weathering effects. Clean crisp text on a clean background. The back cover should look like a freshly printed page, not an aged one.
```

**封底关键要求：**
1. **文字清晰**：封底文字必须清晰可读，不做模糊、噪点、做旧处理
2. **正常文字**：包含版权信息、作者署名、定价等正常出版信息
3. **位置为偶数页**：封底必须排在偶数位置（第10张），确保双面打印后落在书底

**prompt中的中文文字：** 直接在prompt中写明要出现在图片上的中文文字内容，AI生图模型会以像素形式将文字渲染在画面上。

### 第四步：做旧处理

用Python脚本对图片进行做旧处理，转为PNG格式。**注意：封面保持彩色，封底不做旧处理（保持清晰）。**

```python
#!/usr/bin/env python3
from PIL import Image, ImageDraw, ImageFilter, ImageOps
import os, random

INPUT_DIR = "<图片目录>"
random.seed(42)

def add_aged_texture(img, strength=10):
    """添加纸张纹理噪点"""
    w, h = img.size
    noise = Image.new("L", (w, h), 128)
    draw = ImageDraw.Draw(noise)
    for _ in range(w * h // 80):
        x, y = random.randint(0, w-1), random.randint(0, h-1)
        draw.point((x, y), fill=128 + random.randint(-strength, strength))
    noise = noise.filter(ImageFilter.GaussianBlur(radius=1.5))
    return Image.blend(img, noise, alpha=0.08)

def add_vignette(img, strength=25):
    """添加轻微暗角"""
    w, h = img.size
    vignette = Image.new("L", (w, h), 0)
    draw = ImageDraw.Draw(vignette)
    cx, cy = w//2, h//2
    max_r = int((w**2 + h**2)**0.5) // 2
    for i in range(100):
        t = i / 100.0
        r = int(max_r * t)
        draw.ellipse([cx-r, cy-r, cx+r, cy+r], fill=int(strength * t**2))
    vignette = vignette.filter(ImageFilter.GaussianBlur(radius=40))
    vignette = ImageOps.invert(vignette)
    return Image.blend(img, vignette, alpha=0.15)

def add_print_wear(img):
    """添加印刷磨损斑点"""
    w, h = img.size
    wear = Image.new("L", (w, h), 0)
    draw = ImageDraw.Draw(wear)
    for _ in range(w * h // 200):
        x, y = random.randint(0, w-1), random.randint(0, h-1)
        size = random.randint(1, 3)
        draw.ellipse([x, y, x+size, y+size], fill=random.randint(6, 18))
    wear = wear.filter(ImageFilter.GaussianBlur(radius=1.0))
    return Image.blend(img, Image.eval(img, lambda x: min(255, x+10)), alpha=0.03)

def process_page(input_path, output_path, keep_color=False, skip_aging=False):
    """处理图片
    keep_color: 是否保持彩色（封面=True）
    skip_aging: 是否跳过做旧处理（封底=True）
    """
    if keep_color:
        img = Image.open(input_path).convert("RGB")  # 封面保持彩色
    else:
        img = Image.open(input_path).convert("L")  # 内页/封底转纯灰度

    if not skip_aging:
        # 封底不做旧，其他页面做旧
        img = ImageOps.autocontrast(img, cutoff=5)
        img = add_aged_texture(img, strength=10)
        img = add_print_wear(img)
        img = add_vignette(img, strength=25)
        img = img.filter(ImageFilter.GaussianBlur(radius=0.4))  # 印刷网点感
        img = ImageOps.autocontrast(img, cutoff=4)

    img.save(output_path, "PNG")

# ===== 处理所有图片 =====

# 1. 封面：保持彩色 + 做旧处理
inp_cover = os.path.join(INPUT_DIR, "cover.jpg")
out_cover = os.path.join(INPUT_DIR, "cover.png")
process_page(inp_cover, out_cover, keep_color=True, skip_aging=False)
os.remove(inp_cover)

# 2. 内页：黑白版转灰度 + 做旧处理 / 彩色版保持彩色 + 做旧处理
for i in range(1, 9):  # 根据实际页数调整
    inp = os.path.join(INPUT_DIR, f"page0{i}.jpg")
    out = os.path.join(INPUT_DIR, f"page0{i}.png")
    # 黑白版目录: keep_color=False
    # 彩色版目录: keep_color=True
    process_page(inp, out, keep_color=False, skip_aging=False)
    os.remove(inp)

# 3. 封底：不做旧处理，文字清晰可读
inp_back = os.path.join(INPUT_DIR, "back.jpg")
out_back = os.path.join(INPUT_DIR, "back.png")
process_page(inp_back, out_back, keep_color=False, skip_aging=True)
os.remove(inp_back)
```

**彩色版做旧脚本：** 彩色版目录中，内页的 `keep_color=True`，其余逻辑相同。封面和封底处理方式与黑白版一致（封面做旧保持彩色，封底不做旧）。

**运行环境注意：**
- 使用 `/opt/homebrew/bin/python3` 运行
- 需要先 `unset PYTHONHOME` 避免环境冲突
- 安装依赖：`pip install Pillow --break-system-packages`

### 第五步：生成PDF

将所有图片按顺序合成为PDF文件。**不交付HTML**，只交付图片和PDF。

使用Python将图片按页面顺序合并为PDF：

```python
#!/usr/bin/env python3
from PIL import Image
import os, glob

INPUT_DIR = "<图片目录>"
OUTPUT_PDF = "<输出目录>/连环画.pdf"

# 按顺序排列图片：cover, page01~page08, back
page_order = ["cover.png"]
page_order += [f"page0{i}.png" for i in range(1, 9)]
page_order.append("back.png")

images = []
for filename in page_order:
    filepath = os.path.join(INPUT_DIR, filename)
    if os.path.exists(filepath):
        img = Image.open(filepath)
        if img.mode != "RGB":
            img = img.convert("RGB")
        images.append(img)

# 保存为PDF
if images:
    images[0].save(OUTPUT_PDF, save_all=True, append_images=images[1:], resolution=300.0)
    print(f"PDF已生成: {OUTPUT_PDF}，共{len(images)}页")
```

**PDF关键要求：**
- 分辨率300 DPI，适合打印
- 页面顺序：cover(1) → page01(2) → ... → page08(9) → back(10)
- 封底必须是偶数页（第10页），确保双面打印后落在书底
- 每本生成一个PDF文件

**运行环境注意：**
- PDF生成需要Pillow库，安装方式同上
- 如需更高质量的PDF，可使用img2pdf库：`pip install img2pdf --break-system-packages`

## 输出文件结构

```
<输出目录>/
├── <本本标题>/                    # 黑白版
│   ├── 连环画.pdf                 # PDF文件
│   └── images/
│       ├── cover.png             # 封面（彩色+做旧）
│       ├── page01.png ~ page08.png  # 内页（黑白做旧）
│       └── back.png              # 封底（清晰，不做旧）
└── <本本标题>-彩色/                # 彩色版
    ├── 连环画.pdf
    └── images/
        ├── cover.png
        ├── page01.png ~ page08.png
        └── back.png
```

## 关键注意事项

1. **图片比例：** 必须是7:5横屏（2800x2000），prompt中要强调"fill the entire wide horizontal canvas"
2. **文字在图内：** 文字以像素形式由AI生图模型直接渲染在画面上，不是后期合成
2b. **配文精简：** 每页配文控制2-3行以内，从原文中提炼最核心的1-2句话，切勿整段照搬。文字区域仅占上方约18%，插画区域占下方约82%，插画为主体
3. **封面和封底：** 每本必须有封面（cover.png，全彩全画幅、无边框、仅书法标题）和封底（back.png，版权信息），均为AI生成图片。**封面统一彩色**，黑白版的封面也是彩色的
4. **双版本输出：** 每本同步输出黑白版和彩色版两个版本，分别放在两个文件夹中
5. **黑白版：** 内页生成后用Python转为灰度模式（mode=L），去除任何色彩。**封面保持彩色**
6. **彩色版：** 保持RGB模式，用Python添加暖色调、轻微降饱和度，模拟80年代胶印水彩质感。**封面同为彩色**
7. **年代感：** 做旧处理包括纸张纹理、印刷磨损、暗角、网点感。**封面和内页做旧，封底不做旧**（封底文字必须清晰可读）
8. **中文引号：** Python脚本中处理中文引号（""）时用 `\u201c` `\u201d` 转义
9. **作者信息：** 作者信息仅在封底标注，默认为"同济子豪兄 · Trae Work · Seedream"。**封面不放作者名**，仅保留书法标题
10. **交付物：** 只交付**图片（PNG）+ PDF**，不交付HTML。PDF按页面顺序合并所有图片
11. **双面打印：** 封底必须排在偶数页位置。标准10页排列中封底为第10张（偶数）✓。若内页数为奇数张，需调整确保封底落在偶数位
12. **封底清晰：** 封底包含正常出版文字信息（版权、作者、定价等），**不做模糊做旧处理**，文字必须清晰可读

## 参考画风特征（80年代连环画）

skill 内置参考图：`assets/杨家将参考图.jpeg`（杨家将小人书扫描页），以下特征均提炼自该图：

| 特征 | 说明 |
|------|------|
| 工笔白描 | 铁线描（建筑）、兰叶描（织物毛发）、斧劈皴（岩石） |
| 明暗处理 | 高对比黑白、交叉排线、平涂黑块、留白 |
| 构图 | 疏可走马密不透风、S形构图、三远法 |
| 人物 | 7.5-8头身英雄比例、剑眉星目、动态瞬间 |
| 印刷 | 单色黑白、纸张老化、墨迹不均、网点粗糙 |
